# Manifiesto del paquete de revisión

- **Versión del paquete:** `cj-intelligence-r3-cierre-2026-11-01-354de8f63147` (huella = SHA-256 de la lista de archivos con sus SHA-256, abajo)
- **Base:** commit `13f5e639900c` de `Cj-Erp-Web` + cambios **sin commitear** de CJ Intelligence (no se hizo commit, push ni despliegue). Los archivos nuevos no existen en el commit base.
- **Estado en JC_Db:** nada ejecutado. 0 objetos de CJ Intelligence, `IA_Conversacion.IdUsuario` sigue `int`, 15 usuarios inactivos (verificado de solo lectura el 2026-11-01).
- **Archivos:** 93

## Reemplaza
Este ZIP reemplaza por completo: `01_sql_scripts.patch`, `02_backend_codigo.patch`, `03_pruebas.patch`, `04_frontend_y_solucion.patch`,
`05_documentos.patch` (rondas 1–2) y `ronda3_correcciones.patch` (parcial, omitía los archivos nuevos), y la página de revisión (Artifact)
publicada en la ronda anterior, **y las versiones anteriores de este mismo ZIP** (`…cfbcdc4a6942`, SHA-256 `631a84eb…616a3`, y `…6e81b029120e`, SHA-256 `0d99df01642fa49beee500ccc69eb1aae698d8436771c03e3be81e6eda078281`), que no tenían la huella con documento, `IdIdentidad`, auditoría de identidad ni las pruebas de identidad. Los parches se retiraron de la carpeta; este ZIP es el único material vigente.

## Verificación del paquete (distinción importante)
- El **hash SHA-256 del ZIP solo puede verificarse con el archivo ZIP real** (por ejemplo `Get-FileHash -Algorithm SHA256`).
- La **página HTML de revisión permite leer el contenido**, pero **no permite verificar el hash del ZIP**, ni garantiza que los bytes mostrados sean idénticos a los de cada archivo (el navegador puede normalizar saltos de línea). Los hashes por archivo del manifiesto se comprueban contra los archivos extraídos del ZIP, no contra la página.

## Resultados de pruebas (esta versión)
| Capa | Resultado |
|---|---|
| Unitarias (`Tests.Ia`) | 616 pasan, 0 fallan, 9 omitidas (3 corridas idénticas) |
| Controlador, registro e identidad desde la API (`Tests.Api`) | 28 pasan |
| Integración (`Tests.Integration`: SQL, dos sesiones, primer mensaje simultáneo, **identidad de extremo a extremo**, pagos reales, OpenAI) | 9 **omitidas** (preparadas, NO ejecutadas; los resultados unitarios no las sustituyen) |
| Sintaxis SQL (`SET PARSEONLY ON`) | 14 de 14 scripts OK (no es ejecución) |
| Frontend `tsc --noEmit` | 0 errores |

## Archivos y SHA-256
| SHA-256 | Archivo |
|---|---|
| `4e44127300544f5a8a7b92d8a4fa52fe5f4b325eb50f25df40ba2ba2926da631` | CjERP.Backend/CjERP.Api/Configuration/CjIntelligenceRegistration.cs |
| `079303fce7a2133868b0a8203f0535aa71dbc708174b52182ae81c365bd63e11` | CjERP.Backend/CjERP.Api/Controllers/CjIntelligenceController.cs |
| `edb4c3ecb88b814ff9a97577b42700875a6f1de886b4e649a3d3281c9f01810b` | CjERP.Backend/CjERP.Application/DTOs/CjIntelligence/CjIntelligenceDtos.cs |
| `9f57427c5b9af150473bdbf5ce60fe4cdd5bc3e2a57054d79958fadd4c29604e` | CjERP.Backend/CjERP.Application/Interfaces/Services/AI/ICjIntelligenceChatService.cs |
| `092c4a16c721f3416c91557b125d5ff584f85a332c5e576bb6870ed2ab74582f` | CjERP.Backend/CjERP.Backend.sln |
| `39c78a908a9862ced7df02599343ba9e267fbd814ffd05fd77ab63e57dc6c47c` | CjERP.Backend/CjERP.Infrastructure/Persistence/Sql/CjIntelligenceSqlCommandFactory.cs |
| `999acc6d5c174808584e517f771cfcfa01e124028c452323378577f78f3039d4` | CjERP.Backend/CjERP.Infrastructure/Services/AI/CjIntelligence/CjIntelligenceAuthorization.cs |
| `0c432f6c29a55ae7949c62b0def73e915262b58f3cca7bcdd40cd65f8a879ad6` | CjERP.Backend/CjERP.Infrastructure/Services/AI/CjIntelligence/CjIntelligenceChatService.cs |
| `adbeb2e7cd1e941ea6d56a5d8c857fa8cf8855f1d9d3ccad5741b8c89a4335ff` | CjERP.Backend/CjERP.Infrastructure/Services/AI/CjIntelligence/CjIntelligenceData.cs |
| `018bb41c51ec5a9ccc00a0c7642f37f809b3d5d529d30e565799304c6d938c80` | CjERP.Backend/CjERP.Infrastructure/Services/AI/CjIntelligence/CjIntelligenceHistoryGuard.cs |
| `dfc1b0da825c990efcffbb1df0794cb70183f189346d953c85da6fd27f474a0c` | CjERP.Backend/CjERP.Infrastructure/Services/AI/CjIntelligence/CjIntelligenceIdentity.cs |
| `1088d4a8b360fa9e5f3bf7625250adadd2100e968433021b9e1eddb93be6c9f9` | CjERP.Backend/CjERP.Infrastructure/Services/AI/CjIntelligence/CjIntelligencePagosTools.cs |
| `88c8aa492fc835823a03d8ae90d4f81bbeab1c142cd2d90fbb6afe8879dbba9d` | CjERP.Backend/CjERP.Infrastructure/Services/AI/CjIntelligence/CjIntelligenceResultSummarizer.cs |
| `647c95dd56b2c405ecc8f05475ac59a9fadb46766a8cfa2097c64e90e6465a4c` | CjERP.Backend/CjERP.Infrastructure/Services/AI/CjIntelligence/CjIntelligenceTurnLease.cs |
| `808ec6d09356fec407443c70fd8b434633add9880164ca6b26975dfddc8eadde` | CjERP.Backend/CjERP.Infrastructure/Services/AI/Providers/OpenAiToolChatProvider.cs |
| `c542dc33f6b906f8c2a15e9e9298314b32c8c831599500b6a556887be08945ac` | CjERP.Backend/Database/IaChat/18_CjIntelligence_Esquema.sql |
| `ef15344bb1ad0a7c58df520ff7780f5492feb7a915f2e186361545693f43ab6e` | CjERP.Backend/Database/IaChat/18a_CjIntelligence_Snapshot_SoloLectura.sql |
| `f687664370e88365b7e3f76a8f9ed6d1db15c1fb6d4e9f71703d4ce3c643bc54` | CjERP.Backend/Database/IaChat/18b_CjIntelligence_Reversion_PreUso.sql |
| `551d3ecc5d749fa1646be1a2cd24a60b5cc53db68731815497c28d2c4d5f2874` | CjERP.Backend/Database/IaChat/19_CjIntelligence_Procedimientos.sql |
| `7257d0acb41e4b05a572f865946df430aaaefe4ca95d6d4e8bfcd8c637ffcfee` | CjERP.Backend/Database/IaChat/20_CjIntelligence_Usuario_cj_ia.sql |
| `37f23d9cc822d3fb25804ea33aaa5166fe55d39a41e76ec4860864a6380e8848` | CjERP.Backend/Database/IaChat/20b_CjIntelligence_Usuario_cj_ia_Reversion.sql |
| `3eb35f42e4dc47e2185946436dc930378ac373b48a7e19252c3838063bd64b71` | CjERP.Backend/Database/IaChat/20c_CjIntelligence_Firma_Certificado.sql |
| `0eae33ce4ef34ced26cf71736801ad47bb7da966038258198309e0c36456cef8` | CjERP.Backend/Database/IaChat/20d_CjIntelligence_Firma_Certificado_Reversion.sql |
| `80ecdc502879620e84942e8c8f4b97a427d2af38a9d4e1e4454fa971b5f46311` | CjERP.Backend/Database/IaChat/21_CjIntelligence_Validacion_SoloLectura.sql |
| `dedacec68ea33d3aa7d3d4e1dd5f121f1c2393f9746b44b5f48d891c88fee070` | CjERP.Backend/Database/IaChat/21b_CjIntelligence_Validacion_Firma_SoloLectura.sql |
| `e55c6b5d6475451ccb45567d6a8750338fc513f63c120f4b91e637506b8dd34a` | CjERP.Backend/Database/IaChat/22_CjIntelligence_PruebaFuncional.sql |
| `c1adf1ff78015a487435ca24f4aff9bce00a68066e78bd68ca5969510e6ea8ea` | CjERP.Backend/Database/IaChat/23_CjIntelligence_Pruebas_cj_ia.sql |
| `3c6ec506374cac372b84c6433a889249b06a91341648af05320bee3b0141d0ac` | CjERP.Backend/Database/IaChat/23b_CjIntelligence_Limpieza_PorGuid.sql |
| `037b39d2f5be03a18ddc43af65f40006920c2c9cfd8bbdda678b04e904c24f36` | CjERP.Backend/Database/IaChat/24_CjIntelligence_PruebaReal_Pagos_cj_ia.sql |
| `6359c2823c50f46b1c9a216b2c7417fc7a83fc5a3f6a4e72cd1a46620f3cd1d7` | CjERP.Backend/Tests/CjERP.Backend.Tests.Api/CjERP.Backend.Tests.Api.csproj |
| `8ab9c39b67073799995382503e1f3f3f85db308ed9b6eee14eda90cfb38b86d1` | CjERP.Backend/Tests/CjERP.Backend.Tests.Api/CjIntelligenceControllerTests.cs |
| `d487618a10fd9d2d16ef0e7e9445dae3208be3f9fbe1850cf776c1d667d6d460` | CjERP.Backend/Tests/CjERP.Backend.Tests.Api/CjIntelligenceIdentityApiTests.cs |
| `7e60557b4f87ea8513618ba90e966af599908cc4316b4db775e00c16823b955b` | CjERP.Backend/Tests/CjERP.Backend.Tests.Ia/CjERP.Backend.Tests.Ia.csproj |
| `23a5944f1958398b85b23bdba4dba0347d27865fb485e3ed063f1ccee48c926f` | CjERP.Backend/Tests/CjERP.Backend.Tests.Ia/IntegrationTests/ConsultarAsyncConversationRouteTests.cs |
| `1bcf208e260c5782c46a7af74df38361f7a994bdb9257b1cf4632434f2813fa9` | CjERP.Backend/Tests/CjERP.Backend.Tests.Ia/IntegrationTests/ConsultarAsyncSqlFailureTests.cs |
| `48621f2147cce08fc1e7e24fc40a982bf8a0344fdf4933797e2891a2aa74fe39` | CjERP.Backend/Tests/CjERP.Backend.Tests.Ia/IntegrationTests/DiResolutionTests.cs |
| `818ac8006204340c5070a3db6ce754439c1ad9217cdb5a0e6ee64ec62e29d876` | CjERP.Backend/Tests/CjERP.Backend.Tests.Ia/IntegrationTests/GastosQueryExecutorTests.cs |
| `3638172965a0081cfa34ba35396fc02f0ea83e1e81ac5d69ab1166e2f7d51414` | CjERP.Backend/Tests/CjERP.Backend.Tests.Ia/IntegrationTests/GenerarDashboardReporteAsyncTests.cs |
| `b086ba6e7bb9617126d06da428df3d7e604b15f81e1daa3c413d9baa237f8c3b` | CjERP.Backend/Tests/CjERP.Backend.Tests.Ia/IntegrationTests/IaAuditServiceTests.cs |
| `d011023e780e91dc7e9de5af3f9389584664d37645e669e9a52bb714839ff1b1` | CjERP.Backend/Tests/CjERP.Backend.Tests.Ia/IntegrationTests/IaScopeEnforcementOrchestratorTests.cs |
| `8f677bd78dd782b7926645b349f1064e67ff1502ebd40a7ab38db691d6bcacfb` | CjERP.Backend/Tests/CjERP.Backend.Tests.Ia/TestSupport/FakeHttpMessageHandler.cs |
| `7500d1a3e0984aa012f0feacd262501bb0dc3e5ddc36b906923f1bc8c1758df6` | CjERP.Backend/Tests/CjERP.Backend.Tests.Ia/TestSupport/FakeOpenAiChatProvider.cs |
| `667d4cea6119f209e7b0e7d2a1534beff9ad4cbc98f3dd67aa515665735fdc78` | CjERP.Backend/Tests/CjERP.Backend.Tests.Ia/TestSupport/FakeSqlCommandFactory.cs |
| `2ab4a0cf12439116f5061f7835951d11ae14c5f2ecccc1ecbcceadfe8ab0394f` | CjERP.Backend/Tests/CjERP.Backend.Tests.Ia/TestSupport/IaChatServiceReflection.cs |
| `b72c63ee8096c5647085c670d3532ea37165f5d54ebf09fe5f3b8358b6542d0c` | CjERP.Backend/Tests/CjERP.Backend.Tests.Ia/TestSupport/IaChatServiceTestFactory.cs |
| `35291e5b11d5b75ef45ada2ce51c3ade85a31f9694c7fac308d42b752cffde31` | CjERP.Backend/Tests/CjERP.Backend.Tests.Ia/UnitTests/AnthropicMessagesProviderTests.cs |
| `1e00a06d705b393a321ed76575f7348163636e4796a1f75e7c05519f49193125` | CjERP.Backend/Tests/CjERP.Backend.Tests.Ia/UnitTests/BuscarPlanillaArgsGenerationTests.cs |
| `76e2e5df0f4cc951f0990e9f7db09ebf0ba7bfed99774ddaecb0fa9ea37deb2b` | CjERP.Backend/Tests/CjERP.Backend.Tests.Ia/UnitTests/ChartAndAggregationTests.cs |
| `0eafef142f3c3428dd6e4ea675408260a9e7c9cf120351783ac35a1a110880c3` | CjERP.Backend/Tests/CjERP.Backend.Tests.Ia/UnitTests/CjIntelligenceChatServiceTests.cs |
| `30142877b5e05fe1ba67c60be5f7eea45d78f318bdeb33fb2eb1541fcb6c9a22` | CjERP.Backend/Tests/CjERP.Backend.Tests.Ia/UnitTests/CjIntelligenceHistoryGuardTests.cs |
| `753046c30220e5085188311abbc08ee04aab3a6fa38169576b7ee5b85665532f` | CjERP.Backend/Tests/CjERP.Backend.Tests.Ia/UnitTests/CjIntelligenceInfrastructureTests.cs |
| `df42f724426432112facf096446877cc443928048a6b955416b520f1ac85883b` | CjERP.Backend/Tests/CjERP.Backend.Tests.Ia/UnitTests/CjIntelligenceScopeResolverTests.cs |
| `2bc6f5a6524984dc67582e0b1135e4923fb675954803a8eedbde135cfe68972e` | CjERP.Backend/Tests/CjERP.Backend.Tests.Ia/UnitTests/CjIntelligenceToolsAndSummaryTests.cs |
| `0c6246fa107b3d069852293c78472dfaea4782176e23e29b944ccf2a00550fe9` | CjERP.Backend/Tests/CjERP.Backend.Tests.Ia/UnitTests/ClienteMonedaFechaBreakdownTests.cs |
| `204d7321f1b19f65b2fbe18c26ab5e237811d3424a2f4a93179edb0df1afe1ac` | CjERP.Backend/Tests/CjERP.Backend.Tests.Ia/UnitTests/ConversationFilterAccumulationTests.cs |
| `200a2bd0cf8d69b2c889406814700202d1ac9ca46577c556678f0de070f83753` | CjERP.Backend/Tests/CjERP.Backend.Tests.Ia/UnitTests/ConversationFollowUpTests.cs |
| `d4e972b7e1a73c7c7a27b4c9c28aa1f199f15b86306cf1efc0f1f2f877fb2a15` | CjERP.Backend/Tests/CjERP.Backend.Tests.Ia/UnitTests/ErrorHandlingTests.cs |
| `80059cf3ffe0a169e15ffc71fd7895916d99a71072d77f994877ab3b3312bde2` | CjERP.Backend/Tests/CjERP.Backend.Tests.Ia/UnitTests/ExtractedGastosClassesDirectTests.cs |
| `582103bae858992abd40fdbe5da4ead678a793a01a94dc8c2e27379e21e3cc76` | CjERP.Backend/Tests/CjERP.Backend.Tests.Ia/UnitTests/GastosAnalysisServiceDirectTests.cs |
| `212c80122e83f63524d25566b4c91727fc56090af643acf126ffcaf8f3aab6d9` | CjERP.Backend/Tests/CjERP.Backend.Tests.Ia/UnitTests/GastosPaginationScopeTests.cs |
| `6906d5f0e2c649d4dd7756aa25c5cf3006016903c0f492d155a3edd02aae7d52` | CjERP.Backend/Tests/CjERP.Backend.Tests.Ia/UnitTests/GastosQueryExecutorScopeTests.cs |
| `d773c766c160377cc2bf921395a0b5ed8ab9c213ac33c20e8bcc174295cc12aa` | CjERP.Backend/Tests/CjERP.Backend.Tests.Ia/UnitTests/GastosQueryPlannerTests.cs |
| `3aa0423d58cae759073faf21aef118fd810b55ff5dbe3b13721db471ce67198b` | CjERP.Backend/Tests/CjERP.Backend.Tests.Ia/UnitTests/GraphExcelTableWriterTests.cs |
| `63b4928dfece328226eddd4f16f51087669bcb9fb8ea887c661afeb80f713601` | CjERP.Backend/Tests/CjERP.Backend.Tests.Ia/UnitTests/IaAuthorizationServiceTests.cs |
| `e10c69f7e646e827b4e146e9e3306eded59837f8849cce67943913487862c374` | CjERP.Backend/Tests/CjERP.Backend.Tests.Ia/UnitTests/IaDashboardExportServiceTests.cs |
| `16607f8484b7a1314bcbbca3835f1cc2a42a87bedb3b4886f34c11e4da3afb04` | CjERP.Backend/Tests/CjERP.Backend.Tests.Ia/UnitTests/IaExecutiveReportBuilderTests.cs |
| `3c8f603e4a52afe92923a2171460fb1ad1630887cd811770893abdd08220532f` | CjERP.Backend/Tests/CjERP.Backend.Tests.Ia/UnitTests/IaResolvedScopeTests.cs |
| `d755fb0319babeafd7e6caf717d1d4a8c64cb7fcc91dbdb8d510650a92c1270b` | CjERP.Backend/Tests/CjERP.Backend.Tests.Ia/UnitTests/IaScopedSpScriptContractTests.cs |
| `66b69b42534a891d2fea1375f21af8b8876b5eb5423e98e06d9ba47c17b1958e` | CjERP.Backend/Tests/CjERP.Backend.Tests.Ia/UnitTests/IaScopedSpV2ScriptContractTests.cs |
| `ce58e8c512dd268ff64265c9e0e7799387ff9d6b72a4e9b3935963d7c61c83fd` | CjERP.Backend/Tests/CjERP.Backend.Tests.Ia/UnitTests/IaScopedSpV3ScriptContractTests.cs |
| `27f361d5c66fa419eda9f89217872b3ada2e1406a00837a7da5668947a4f3242` | CjERP.Backend/Tests/CjERP.Backend.Tests.Ia/UnitTests/IaTextUtilsDirectTests.cs |
| `e6e3865799b2f249afb4ed48dc04396c2500093b05c3e5da0e65d39ab0615826` | CjERP.Backend/Tests/CjERP.Backend.Tests.Ia/UnitTests/InMemoryIaConversationStoreTests.cs |
| `80ebab85b7d7661c1def3c210e6e4141b1744004909f7a227b41e9bd672d0c17` | CjERP.Backend/Tests/CjERP.Backend.Tests.Ia/UnitTests/JwtServiceRenewTokenTests.cs |
| `b49744e56052cf868608f71b1aa0db2615048aac4e36cc9ab7e008e8d54f25c0` | CjERP.Backend/Tests/CjERP.Backend.Tests.Ia/UnitTests/OfferedBreakdownFollowUpTests.cs |
| `b80a890530acfe8fc9e7703144fd3a4933a6ae93c12854931665e6448765cfe9` | CjERP.Backend/Tests/CjERP.Backend.Tests.Ia/UnitTests/OpenAiChatProviderTests.cs |
| `7517cb7796d3b365f23a9798d4be5bc2acd91fcbf58e9294cdd2efdca4e4bda5` | CjERP.Backend/Tests/CjERP.Backend.Tests.Ia/UnitTests/OpenAiToolChatProviderTests.cs |
| `8087172f263e1033468416a952ce5d1787f0272f318bf14b50438e3d03e4d5f0` | CjERP.Backend/Tests/CjERP.Backend.Tests.Ia/UnitTests/OrdenCompraBandejaTests.cs |
| `734947b44f2d2e7ce76b5876d0f41488bc16d78cd8b0662ea9763ed9c1337d85` | CjERP.Backend/Tests/CjERP.Backend.Tests.Ia/UnitTests/PromptGuardrailsTests.cs |
| `3c0b19a51d216f8b5ddeffc6734fed4a327552e6ff05ac34bbfde74760b85d5b` | CjERP.Backend/Tests/CjERP.Backend.Tests.Ia/UnitTests/RelaxedFilterCandidatesTests.cs |
| `90d59073dad623a39faf2a84c179f6e40c3eff94f785a0e269b291939d5ebbc5` | CjERP.Backend/Tests/CjERP.Backend.Tests.Ia/UnitTests/ResponseGeneratorTests.cs |
| `923bc7e7b25e8630f2833c84904d79a465f679165ad81d8de0d1caf1aff70980` | CjERP.Backend/Tests/CjERP.Backend.Tests.Ia/UnitTests/ResumenSqlRouteTests.cs |
| `8aa6d8798e316bda7ebdbd21673bb46c10a366540c11abdd3c466182008dd53b` | CjERP.Backend/Tests/CjERP.Backend.Tests.Ia/UnitTests/UnavailableFieldsTests.cs |
| `85492b6dacfe031d46f49a4a3abf9e628900a2f7d5a04d1b3239306a433e9ac1` | CjERP.Backend/Tests/CjERP.Backend.Tests.Integration/CjERP.Backend.Tests.Integration.csproj |
| `fe69613cb4bd153e9beb3170e52a02dad9ac3865826181f53cdb6f1d87d947c3` | CjERP.Backend/Tests/CjERP.Backend.Tests.Integration/IdentityIntegrationTests.cs |
| `7120645f8ce03d57865d586cecaa8c3e7c84269fc8d31603e9d1577e20da6186` | CjERP.Backend/Tests/CjERP.Backend.Tests.Integration/IntegrationTests.cs |
| `0b4363bb0b43104b16d71d90d9bff795b97c43857930d1a2c4b228a8c3dde4ad` | CjERP.Backend/Tests/CjERP.Backend.Tests.Integration/TestGates.cs |
| `2b8e23bcbd75bd33319d3218c7a9368a488bd725791ba30d1eb6a3bb4bbd2d6e` | cjerp-frontend/src/features/cj-intelligence/CjIntelligencePage.tsx |
| `67c1170ffad6da231e5f72b38b0809629879402afdfb91c59dce7c049eb83780` | cjerp-frontend/src/features/cj-intelligence/types.ts |
| `0ecdd6bace8af18ce480837cbbba07298ddac7003385ef4a5a68c0344686d8d6` | docs/CJ_INTELLIGENCE_DECISIONES_PENDIENTES.md |
| `7722d8b176d1afd11aa0d0a11353487bf7c38456e4bb409589bb9293cab2f1d8` | docs/CJ_INTELLIGENCE_DISENO.md |
| `86a031552aed599d859f69f49541ce26b4ab56f0d32f4626755482c1c5f5e943` | docs/CJ_INTELLIGENCE_IDENTIDAD.md |
| `a36efc03f92d8d235a197dd1509f52a7c507da5f0d4f250893e8289b92491fa3` | docs/CJ_INTELLIGENCE_PILOTO_CONTROL_IDENTIDAD.md |
| `f21d18fa9eb095540fb81214a27944eb6e0d5168ad8bf8c7ca6c6e01d7db73e3` | docs/HALLAZGO_RESPALDO_LOG_JC_Db.md |
