using System.Text.Json;
using CjERP.Application.Interfaces.Services.AI;
using CjERP.Infrastructure.Services;
using Xunit;

namespace CjERP.Backend.Tests.Ia.UnitTests;

/// <summary>
/// PRUEBAS SINTETICAS de la ruta de resumen calculado en SQL (modo RESUMEN de sp_IA_Planilla_Buscar): deteccion de
/// dimensiones en la pregunta, parametros enviados al store y payload para el redactor. No ejecutan SQL.
/// </summary>
[Trait("Category", "Unit")]
public sealed class ResumenSqlRouteTests
{
    [Theory]
    [InlineData("gastos por cliente y moneda para el mes de setiembre 2026", "CLIENTE,MONEDA")]
    [InlineData("gastos por cliente, moneda y fecha", "CLIENTE,MONEDA,FECHA")]
    [InlineData("resumen de gastos por mes", "MES")]
    [InlineData("cuanto se gasto por site", "SITE")]
    [InlineData("gastos por responsable y estado", "RESPONSABLE,ESTADO")]
    [InlineData("gastos por tipo de pago", "TIPOPAGO")]
    [InlineData("gastos por moneda y por cliente", "MONEDA,CLIENTE")]
    [InlineData("gastos de huaman callupe por coincidencia", "COINCIDENCIA")]
    public void DetectaLasDimensionesDeAgrupacion(string pregunta, string esperadas)
    {
        Assert.True(BuscarPlanillaQuestionHeuristics.TryResolveSummaryDimensions(pregunta, out var dimensions));
        Assert.Equal(esperadas.Split(','), dimensions);
    }

    [Theory]
    [InlineData("gastos por cliente", "CLIENTE")]
    [InlineData("gastos por proyecto", "CLIENTE,PROYECTO")]
    [InlineData("gastos por site", "CLIENTE,PROYECTO,SITE")]
    [InlineData("gastos por tipo de trabajo", "CLIENTE,PROYECTO,SITE")]
    [InlineData("gastos por tarea", "CLIENTE,PROYECTO,SITE")]
    [InlineData("gastos por site y moneda", "CLIENTE,PROYECTO,SITE")]
    [InlineData("gastos por proyecto y estado", "CLIENTE,PROYECTO,ESTADO")]
    [InlineData("gastos por responsable y estado", "RESPONSABLE,ESTADO")]
    public void AgrupaSegunLaJerarquiaClienteProyectoSite(string pregunta, string esperadas)
    {
        Assert.True(BuscarPlanillaQuestionHeuristics.TryResolveSummaryDimensions(pregunta, out var dimensions));
        Assert.Equal(esperadas.Split(','), BuscarPlanillaQuestionHeuristics.ApplyHierarchicalGrouping(dimensions));
    }

    [Theory]
    [InlineData("Claro", null, null, "gastos del cliente Claro", "CLIENTE")]
    [InlineData("Claro", "Torres", null, "gastos del proyecto Torres", "CLIENTE,PROYECTO")]
    [InlineData("Claro", "Torres", "Lima 01", "gastos del site Lima 01", "CLIENTE,PROYECTO,SITE")]
    [InlineData(null, null, null, "gastos de setiembre", null)]
    [InlineData("Claro", null, null, "detalle de gastos del cliente Claro", null)]
    public void UnaConsultaFiltradaSeResumeSegunLaJerarquia(string? cliente, string? proyecto, string? site, string pregunta, string? esperadas)
    {
        var args = new BuscarPlanillaArgs { Cliente = cliente, Proyecto = proyecto, Site = site };

        var resuelto = BuscarPlanillaQuestionHeuristics.TryResolveDimensionsFromFilters(args, pregunta, out var dimensions);

        Assert.Equal(esperadas is not null, resuelto);
        Assert.Equal(esperadas?.Split(',') ?? [], dimensions);
    }

    [Fact]
    public void ElResumenJerarquicoSeAgregaAlPayloadSinPerderElDetalle()
    {
        var resumen = new PlanillaResumenExecutionResult
        {
            Groups = [new() { ["Cliente"] = "CLARO", ["Moneda"] = "SOLES", ["Registros"] = 2 }],
            TotalsByCurrency = [new() { ["Moneda"] = "SOLES", ["Registros"] = 2 }],
            TotalRows = 2
        };

        var node = (System.Text.Json.Nodes.JsonObject)GastosAnalysisService.AddHierarchicalSummary(
            new { totalRows = 2 }, ["CLIENTE"], resumen);

        Assert.Equal(2, (int)node["totalRows"]!);
        Assert.Equal("CLARO", (string)node["hierarchicalSummary"]!["groups"]![0]!["Cliente"]!);
    }

    [Fact]
    public void UnMismoSiteConVariasMonedas_QuedaJuntoConTodasSusMonedas()
    {
        static Dictionary<string, object?> Fila(string site, string moneda) => new()
        {
            ["Cliente"] = "CLARO", ["Proyecto"] = "P1", ["Site"] = site, ["Moneda"] = moneda,
            ["Registros"] = 1, ["TotalMonedaOriginal"] = 10m
        };

        var ordenadas = GastosAnalysisService.KeepCurrenciesTogether(
            [Fila("A", "SOLES"), Fila("B", "SOLES"), Fila("A", "DOLARES"), Fila("B", "DOLARES")]);

        Assert.Equal(new[] { "A", "A", "B", "B" }, ordenadas.Select(f => (string)f["Site"]!));
        Assert.Equal(new[] { "SOLES", "DOLARES", "SOLES", "DOLARES" }, ordenadas.Select(f => (string)f["Moneda"]!));
    }

    [Theory]
    [InlineData("gastos pendientes de setiembre 2026")]
    [InlineData("gastos del cliente Claro")]
    [InlineData("gastos por aprobar")]                        // "por aprobar" no es una dimension
    [InlineData("detalle de gastos por cliente")]              // pide el detalle
    [InlineData("listado de gastos por moneda")]
    [InlineData("")]
    public void NoUsaElResumen_SiNoHayAgrupacionOSePideElDetalle(string pregunta)
    {
        Assert.False(BuscarPlanillaQuestionHeuristics.TryResolveSummaryDimensions(pregunta, out var dimensions));
        Assert.Empty(dimensions);
    }

    [Theory]
    [InlineData("HUAMAN CALLUPE RONALDO DIDI", "pasame el desglose de HUAMAN CALLUPE RONALDO DIDI para el periodo indicado", true)]
    [InlineData("Huaman Callupe", "gastos de Huaman Callupe en setiembre", true)]
    [InlineData("combustible peaje", "gastos de combustible peaje", false)]            // palabras comunes, no un nombre
    [InlineData("huaman callupe", "gastos de huaman callupe", false)]                  // escrito en minusculas
    [InlineData("SDP", "gastos de SDP en setiembre", false)]                            // una sola palabra
    [InlineData("HUAMAN CALLUPE", "detalle de gastos de HUAMAN CALLUPE", false)]       // pide el detalle
    public void DetectaLaBusquedaPorNombre(string textoBusqueda, string pregunta, bool esperado)
    {
        var args = new BuscarPlanillaArgs { TextoBusqueda = textoBusqueda };

        Assert.Equal(esperado, BuscarPlanillaQuestionHeuristics.IsNameSearch(args, pregunta));
    }

    [Fact]
    public void UnaBusquedaPorNombreConFiltroDeCampo_NoEsBusquedaPorNombre()
    {
        var args = new BuscarPlanillaArgs { TextoBusqueda = "HUAMAN CALLUPE", Solicitante = "HUAMAN CALLUPE" };

        Assert.False(BuscarPlanillaQuestionHeuristics.IsNameSearch(args, "gastos del solicitante HUAMAN CALLUPE"));
    }

    [Fact]
    public void LosParametrosDelResumen_AgreganElModoSinPerderElAlcance()
    {
        var args = new BuscarPlanillaArgs { Estados = "PAGADO", FechaInicio = new DateOnly(2026, 9, 1), FechaFin = new DateOnly(2026, 9, 30) }.Normalize();
        var scope = IaResolvedScope.ForTotal(canViewGlobalTotals: false);

        var parameters = GastosQueryExecutor.BuildResumenParameters(args, ["CLIENTE", "MONEDA"], top: 200, scope);

        Assert.Equal("RESUMEN", parameters.Get<string>("Modo"));
        Assert.Equal("CLIENTE,MONEDA", parameters.Get<string>("AgruparPor"));
        Assert.Equal(200, parameters.Get<int>("Top"));
        Assert.Equal("TOTAL", parameters.Get<string>("AlcanceNivel"));       // el alcance viaja igual que en el detalle
        Assert.Equal("PAGADO", parameters.Get<string>("Estados"));
        Assert.Equal("20260901", parameters.Get<string>("FechaInicio"));
    }

    [Fact]
    public void ElPayloadDelResumen_IncluyeGruposYTotalesPorMoneda_SinFilasDeDetalle()
    {
        var result = new PlanillaResumenExecutionResult
        {
            Groups = [new() { ["Cliente"] = "AMX", ["Moneda"] = "SOLES", ["Registros"] = 3 }],
            TotalsByCurrency =
            [
                new() { ["Moneda"] = "SOLES", ["Registros"] = 3 },
                new() { ["Moneda"] = "DOLARES", ["Registros"] = 1 }
            ],
            TotalRows = 4
        };

        var payload = GastosAnalysisService.BuildResumenAnalysisPayload(
            "gastos por cliente y moneda", new BuscarPlanillaArgs().Normalize(), ["CLIENTE", "MONEDA"], result,
            new Dictionary<string, object?>(), new Dictionary<string, object?>());

        using var json = JsonDocument.Parse(JsonSerializer.Serialize(payload));
        var root = json.RootElement;

        Assert.Equal("sql_summary", root.GetProperty("assumptions").GetProperty("analysisMode").GetString());
        Assert.Equal(4, root.GetProperty("totalRows").GetInt32());
        Assert.True(root.GetProperty("hasMultipleCurrencies").GetBoolean());
        Assert.Equal(2, root.GetProperty("totalsByCurrency").GetArrayLength());
        Assert.Equal(1, root.GetProperty("groups").GetArrayLength());
        Assert.False(root.TryGetProperty("detailSample", out _));
        Assert.False(root.TryGetProperty("topRecords", out _));
    }
}
